<html>

<head>
<title>Unisel Homestay Reservation</title>
</head>
<body>

	<?php
	$checkin_date =  date('y-m-d', strtotime($_POST['checkin']));
	$checkout_date =  date('y-m-d', strtotime($_POST['checkout']));
	echo "<br>".$checkin_date."<br>";
	echo $checkout_date;
	include './auth.php';
	
	
	$result = mysqli_query($conn, "select * from homestay  where homestay.homestay_id in 
		  (
              select booking.homestay_id
              from booking 
	       )");
	// while ($row = mysqli_fetch_array($result)) {
	//  print "					<p><h4>".$sub_row2['homestay_name']."</h4></p>\n";
	// 							print "					<div class=\"row\">\n";
	// 							print "					\n";
	// 							print "						<div class=\"large-4 columns\">\n";
	// 							print "							<img src=\" ../".$sub_row2['imgpath']."\"></img>\n";
	// 							print "						</div>\n";
	// 							print "						<div class=\"large-4 columns\">\n";
	// 							print "						<p><span class=\"fontgrey\"> Total Room : </span> ".$sub_row2['total_room']."<br>\n";
	// 							print "						<span class=\"fontgrey\"> Address : </span> ".$sub_row2['address']."\n";
	// 							print "						<br><span class=\"fontgrey\">Descriptions  : </span> ".$sub_row2['descriptions']."</p>\n";
								
								
	// 							print "\n";
	// 							print "						</div>\n";
	// 							print "						<div class=\"large-4 columns\">\n";
	// 							print "						<p ><span class=\"fontgrey\">Rate : MYR </span><span style=\"font-size:24px;\">".$sub_row['rate']."</span><span class=\"fontgrey\">/ night</span><br>\n";
	// 							print "						<span style=\"text-align:right;\">".$row['availablehomestay']." homestay available</span>\n";
	// 							print "						</p>\n";
	// 							print "							<div class=\"row\">\n";
	// 							print "								<div class=\"large-11 columns\">\n";
	// 							print "									<label class=\"fontcolor\">\n";
	// 							print "										<select  class=\"no_of_homestay\" name=\"qtyhomestay".$sub_row['homestay_id']."\" id=\"homestay".$sub_row['homestay_id']."\" onChange=\"selection(".$sub_row['homestay_id'].")\"  style=\"width:100%; color:black; height:45px;\" ;\">\n";
	// 							print "											<option  value=\"0\">0</option>\n";
	// 																			$i = 1;
	// 																			while($i <= $row['availablehomestay'])
	// 																			{
	// 							print "											<option value=\"".$i."\">".$i."</option>\n";	
	// 																			$i = $i+1;
	// 																			}
	// 							print "										</select>\n";
	// 							print "									</label>\n";
	// 							print "								</div>\n";
	// 							print "								<div class=\"large-1 columns\">\n";
	// 						    print "<input type=hidden name=\"selectedhomestay".$sub_row['homestay_id']."\"  id=\"selectedhomestay".$sub_row['homestay_id']."\" value=\"".$sub_row['homestay_id']."\">";
	// 							print "<input type=hidden name=\"homestay_name".$sub_row['homestay_id']."\" id=\"homestay_name".$sub_row['homestay_id']."\" value=\"".$sub_row['homestay_name']."\">";
	// 							print "								</div>\n";
	// 							print "							</div>\n";
	// 							print "						</div>\n";
	// 							print "						\n";
	// 							print "					</div>\n";
	// 							print "					\n";
	// 							print "				<hr>";
	   
	// }
	mysql_close($dbhandle);
	
	?>
</body>
</html>