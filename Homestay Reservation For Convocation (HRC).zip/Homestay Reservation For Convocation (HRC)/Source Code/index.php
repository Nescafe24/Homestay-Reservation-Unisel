<?php
session_start();
?>
 
<!DOCTYPE html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Unisel Homestay Reservation</title>
<link rel="stylesheet" href="scss/normalize.css">
<link rel="stylesheet" href="scss/foundation.css">
<link rel="stylesheet" href="scss/style.css">
<link rel="stylesheet" href="scss/datepicker.css">
<link href="scss/datepicker.css" rel="stylesheet" type="text/css"/>  
<link href='http://fonts.googleapis.com/css?family=Slabo+13px' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


<script>
  $(document).ready(function() {
		$("#checkout").datepicker();
		$("#checkin").datepicker({
		minDate : new Date(),
		onSelect: function (dateText, inst) {
        var date = $.datepicker.parseDate($.datepicker._defaults.dateFormat, dateText);
        $("#checkout").datepicker("option", "minDate", date);
		}
		});
  });
</script>
<link href='http://fonts.googleapis.com/css?family=Slabo+27px' rel='stylesheet' type='text/css'>
<meta class="foundation-data-attribute-namespace"><meta class="foundation-mq-xxlarge"><meta class="foundation-mq-xlarge"><meta class="foundation-mq-large"><meta class="foundation-mq-medium"><meta class="foundation-mq-small">
<style>
	
h1 { 
	text-align: center;
	color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
 }
 h2 {
 	text-align: left;
 }
 p.test1{
 	text-align: left;
 	color: white;
 	text-indent: 50px;
 	 text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
 }
 .navbar{
		background-color: black;
		text-align: right;
		color: white;
	}

</style><meta class="foundation-mq-topbar"></head>
<body class="fontbody" style="background-image : url(img/background.jpg); background-size: cover; background-repeat: no-repeat;background-attachment: fixed;">
<nav class="navbar navbar-expand-lg navbar-light">

  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" style="color: white" href="login.php">Sign In <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
      <a class="nav-link" style=" color: white" href="uploadfile.php">Upload Receipt</a>
      </li>
         
    </ul>
  </div>
</nav>
	
 <h1> HOMESTAY RESERVATION PORTAL </h1>

<div class="row foo" style="margin:20px auto 20px auto;"><br><br>
<p class="test1">Selamat datang ke Homestay Reservation Portal . Sebuah “One-Stop Portal”  carian dan tempahan yang disediakan untuk kemudahan warga unisel mahupun keluarga warga  mencari homestay yang berdekatan Unisel Kampus Bestari Jaya tanpa memerlu mencari secara manual atau membuat carian di internet</p>
</div>
</div>
<div class="row" style="padding-left: 100px;">
	<div class="large-4 columns blackblur fontcolor" style="padding-top:20px;">
	
	<div class="large-12 columns "  >
	<p><b style="color: white">Check Date</b></p><hr class="line">
			<form name="form" action="checkroom.php" method="post" onSubmit="return validateForm(this);">
			<div class="row">
				
					<div class="large-6 columns" style="max-width:100%;">
						<label class="fontcolor" for="checkin">Check In
							<input name="checkin" id="checkin" style="width:100%;"/>
						</label>
					</div>
			
					
					<div class="large-6 columns" style="max-width:100%;">
						<label class="fontcolor" for="checkout">Check Out
							<input name="checkout" id="checkout" style="width:100%;"/>
						</label>
					</div>
			</div><br>
			
			  <div class="row">
				<div class="large-6 columns" >
					<button name="submit" href="#" class="button small fontslabo" style="background-color: #2ecc71 ; width:110%;" >Check Availability</button>
				</div>
			  </div>
			</form>
	</div>
</div>
</div>

<script>
	function validateForm(form) {
		var a = form.checkin.value;
		var b = form.checkout.value;
			if(a == null || b == null || a == "" || b == "") 
			{
			 alert("Please choose date");
			 return false;
			}
			
			

	}
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-57205452-1', 'auto');
  ga('send', 'pageview');

</script>




</body></html>