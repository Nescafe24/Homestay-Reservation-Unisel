<?php

$db_host = "localhost";
$db_user = "alitisam_faizul";
$db_pass = "TYU567ghj%^&";
$db_name = "alitisam_syawal";

 
 
 $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name) ;
if ($conn) {
	// echo "connected successfully";
}

?>