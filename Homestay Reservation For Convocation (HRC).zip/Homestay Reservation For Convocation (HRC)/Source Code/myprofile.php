<?php
session_start();
include './auth.php';
$re = mysqli_query($conn , "select * from user where username = '".$_SESSION['username']."'  AND password = '".$_SESSION['password']."' " );
echo mysqli_error($conn);
if(mysqli_num_rows($re) > 0)
{

} 
else
{

session_destroy();
header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="http://getbootstrap.com/favicon.ico">

    <title>Homestay Reservation System</title>

  
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <
    <link href="css/dashboard.css" rel="stylesheet">

    
  <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
  <link href="css/datepicker.css" rel="stylesheet" type="text/css"/>
  <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
    
 
  <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/animation.css">

 </head>
  <script>
   
    
  </script>
  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid" style="background-color: #4aa3df;">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#" style="color: #ffffff;">Homestay  Panel</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="signout.php" style="color: #ffffff;">Sign Out</a></li>
          </ul>
        </div>
      </div>
    </nav>
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li ><a href="dashboard.php"><i class="icon-gauge"></i> Booking <span class="sr-only">(current)</span></a></li>
            <li class="active"><a href="myprofile.php" style="color: blue;"><i class="icon-key"></i> My Profile </a></li>
      <li ><a href="homestay.php"style="color: blue;"><i class="icon-key"></i> Manage Homestay</a></li>
      <li><a href="paymentproof.php" style="color: blue;"><i class="icon-key"></i> Payment </a></li>
      
      
          </ul>

        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main" id="roomdetail">
          
      

          <h2 class="sub-header">User Details</h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Particulars</th>
                  <th>Descriptions</th>
                </tr>
              </thead>
              <tbody id="userinfo"  >
          <?php 
            include './auth.php';
            $result = mysqli_query($conn ," select * from user where username = '".$_SESSION['username']."'  AND password = '".$_SESSION['password']."' ");
            if(mysqli_num_rows($result) > 0){
              while ($row = mysqli_fetch_array($result) ){
                  print "       <tr><td> Username</td>\n";
                  print "       <td>".$row['username']." </td></tr>\n";
                  print "       <tr><td> Fullname</td>\n";
                  print "       <td>".$row['fullname']." </td></tr>\n";
                  print "       <tr><td> Address</td>\n";
                  print "       <td>".$row['address']." </td></tr>\n";
                  print "       <tr><td> Email</td>\n";
                  print "       <td>".$row['email']." </td></tr>\n";
                  print "       <tr><td> Phone number</td>\n";
                  print "       <td>".$row['phonenumber']." </td></tr>\n";
                  print "       <tr><td> Password</td>\n";
                  print "       <td>".$row['password']." </td></tr>\n";

                print "                  <td><a href=\"editprofile.php?user_id=".$row['user_id']."\" \">Edit</a></td><td>";          
          
              }
            }     
          
          ?>
        
               
              </tbody>
            </table>
          </div>
      <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main" id="formnew" style="display:none;">
    <button type="button" class="btn" id="back">Back</button>
          
    </div>
        </div>
   

    
  <script>
  $( document ).ready(function() {
      $("#addhomestay").click(function(){
    $("#formnew").toggle();
    $("#addhomestay").toggle();
    });
    $("#back").click(function(){
    $("#addhomestay").toggle();
    $("#formnew").toggle();
    });
  });
  function moredetail(id)
  {
  var x = "booking"+id;
  document.getElementById(x).style.display = "block";
  }
  
  $('.delete').click (function () {
    return confirm ("Are you sure you want to delete?") ;
  }); 
  
  </script>

<div id="global-zeroclipboard-html-bridge" class="global-zeroclipboard-container" title="" style="position: absolute; left: 0px; top: -9999px; width: 15px; height: 15px; z-index: 999999999;" data-original-title="Copy to clipboard">      <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" id="global-zeroclipboard-flash-bridge" width="100%" height="100%">         <param name="movie" value="/assets/flash/ZeroClipboard.swf?noCache=1416326489703">         <param name="allowScriptAccess" value="sameDomain">         <param name="scale" value="exactfit">         <param name="loop" value="false">         <param name="menu" value="false">         <param name="quality" value="best">         <param name="bgcolor" value="#ffffff">         <param name="wmode" value="transparent">         <param name="flashvars" value="trustedOrigins=getbootstrap.com%2C%2F%2Fgetbootstrap.com%2Chttp%3A%2F%2Fgetbootstrap.com">         <embed src="/assets/flash/ZeroClipboard.swf?noCache=1416326489703" loop="false" menu="false" quality="best" bgcolor="#ffffff" width="100%" height="100%" name="global-zeroclipboard-flash-bridge" allowscriptaccess="sameDomain" allowfullscreen="false" type="application/x-shockwave-flash" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" flashvars="trustedOrigins=getbootstrap.com%2C%2F%2Fgetbootstrap.com%2Chttp%3A%2F%2Fgetbootstrap.com" scale="exactfit">                </object></div><svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200" preserveAspectRatio="none" style="visibility: hidden; position: absolute; top: -100%; left: -100%;"><defs></defs><text x="0" y="10" style="font-weight:bold;font-size:10pt;font-family:Arial, Helvetica, Open Sans, sans-serif;dominant-baseline:middle">200x200</text></svg></body></html>