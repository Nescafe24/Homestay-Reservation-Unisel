<?php
session_start();

include './auth.php';
$re = mysqli_query($conn , "select * from admin where username = '".$_SESSION['username']."'  AND password = '".$_SESSION['password']."' " );
echo mysqli_error($conn);
if(mysqli_num_rows($re) > 0)
{

} 
else
{
session_destroy();
header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <meta name="description" content="">
    <meta name="author" content="">
 

    <title>Unisel Reservation System</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    
    <link href="css/dashboard.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
	<link href="css/datepicker.css" rel="stylesheet" type="text/css"/>
	<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
	<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
  <link rel="stylesheet" href="css/fontello.css">
    <link rel="stylesheet" href="css/animation.css">


 </head>
	<script>
	  
	</script>
  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid" style="background-color: #4aa3df;">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#" style="color: #ffffff;">Admin  Panel</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="signout.php" style="color: #ffffff;">Sign Out</a></li>
          </ul>
        </div>
      </div>
    </nav>
	
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li ><a href="dashboard.php"><i class="icon-gauge"></i> Dashboard <span class="sr-only"></span></a></li>

            <li class="active"><a href="myprofile.php"><i class="icon-key"></i> My Profile</a></li>
			<li><a href="homestay.php"><i class="icon-key"></i> Homestay</a></li>
			<li><a href="reg-user.php"><i class="icon-key"></i> Registered User</a></li>
			<li><a href="paymentproof.php"><i class="icon-key"></i> Payment </a></li>
			
          </ul>

        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
         
		 
			 <h2 class="sub-header">My Profile</h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Profile Detail</th>
                  <th> </th>
                </tr>
              </thead>
              <tbody >
			  <?php 
			  include './auth.php';
			  $result = mysqli_query($conn, "Select * from admin where id");
				if( mysqli_num_rows($result) >0){
					while ($rows = mysqli_fetch_array($result)){
										
					print "				<tr><td>id</td>\n";
					print "				<td>".$rows['id']." </td></tr>\n";
					print "				<tr><td>Username</td>\n";
					print "             <td>".$rows['username']."</td></tr>\n";
					print "				<tr><td>Full Name</td>\n";
					print "				<td>".$rows['fullname']."</td></tr>\n";
					print "				<tr><td>Contact Number</td>\n";
					print "				<td>".$rows['phonenumber']."</td></tr>\n";
					print "				<tr><td>Email</td>\n";
					print "				<td>".$rows['email']."</td></tr>\n";
					print "				<tr><td>Password</td>\n";
					print "				<td>".$rows['password']."</td></tr>\n";
					
								
					
					}
				
				}
			  ?>
				
              </tbody>
            </table>
          </div>
		  <button type="button" class="btn" id="editbook">Edit</button>
        </div>
		
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main editbooking" style="display:none">
			 <button type="button" class="btn" id="back">Back</button><hr>
				 <form  role="form" action="updateprofile.php" method="post">
					
						 <div class="form-group">
	
						<?php
						include './auth.php';
						$id = $_GET['profile'];
						$r = mysqli_query($conn, "select * from admin where id=".$id."");
						if(mysqli_num_rows($r)>0){
							while($rows = mysqli_fetch_array($r))
							{
print "							<label for=\"paymentstatus\">Payment Status</label>\n";
print "				<input type=\"hidden\" name=\"bookingid\" id=\"bookingid\" value=\"".$id."\">			<select  type=\"text\" class=\"form-control\" name=\"paymentstatus\" id=\"paymentstatus\" placeholder=\"confirmed or pending\" required><option value=\"\"></option><option value=\"confirmed\">confirmed</option><option value=\"pending\">Pending</option></select>\n";
print "\n";
print "							<hr>\n";
print "						<label for=\"firstname\">First Name</label>	<input type=\"text\" class=\"form-control\" name=\"firstname\" id=\"firstname\" placeholder=\"First Name\" value=\"".$rows['first_name']."\">\n";
print "						<hr><label for=\"lastname\">Last Name</label>	<input type=\"text\" class=\"form-control\" name=\"lastname\" id=\"lastname\" placeholder=\"Last Name\" value=\"".$rows['last_name']."\">\n";
print "						<hr><label for=\"email\">Email</label>	<input type=\"text\" class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"Email\" value=\"".$rows['email']."\">\n";
print "						<hr><label for=\"telephone\">Telephone</label>	<input type=\"text\" class=\"form-control\" name=\"telephone\" id=\"telephone\" placeholder=\"Phone No.\" value=\"".$rows['telephone_no']."\">";

							}
						
						}
						
						?>	
					

						  </div>

				  <hr><button type="submit" class="btn btn-default">Update</button>
				</form>
		</div>
      </div>
    </div>
	

    
  <script>
  $( document ).ready(function() {
      $("#editbook").click(function(){
		$(".editbooking").toggle();
		$(".bookinginfo").toggle();
	  });
	  $("#back").click(function(){
		$(".editbooking").toggle();
		$(".bookinginfo").toggle();
	  });
	});
	function moredetail(id)
	{
	var x = "booking"+id;
	document.getElementById(x).style.display = "block";
	}
  </script>

</body></html>