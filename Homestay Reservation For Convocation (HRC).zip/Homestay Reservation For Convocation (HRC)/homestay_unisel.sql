-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2019 at 12:29 PM
-- Server version: 5.6.45-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homestay_unisel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `username` varchar(10) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phonenumber` varchar(13) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `fullname`, `email`, `phonenumber`, `password`) VALUES
(2, 'Admin', 'Admin', 'Admin@gmail.com', '0000000', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(200) NOT NULL,
  `homestay_name` varchar(255) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `special_requirement` text NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `total_amount` double DEFAULT NULL,
  `deposit` double NOT NULL,
  `booking_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telephone_no` varchar(30) NOT NULL,
  `add_line1` varchar(100) NOT NULL,
  `add_line2` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `postcode` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `homestay_name`, `checkin_date`, `checkout_date`, `special_requirement`, `payment_status`, `total_amount`, `deposit`, `booking_date`, `first_name`, `last_name`, `email`, `telephone_no`, `add_line1`, `add_line2`, `city`, `state`, `postcode`, `country`) VALUES
(13, '', '2019-07-12', '2019-07-13', '', 'PAID', 120, 12, '2019-07-11 19:52:58', '', '', '', '', 'Jalan Banting Baru 3/6, ', 'Taman Banting Baru', 'Banting', 'Selangor', '42700', 'Malaysia'),
(14, '', '2019-07-16', '2019-07-17', '', 'PAID', 150, 15, '2019-07-14 18:14:11', 'Muhammad Ikhmal ', 'Salim', 'Ikhmal@gmail.com', '01459687712', 'Jalan Sg Besar,', 'Taman Alam Perdana', 'Sg Besar', 'Selangor', '48110', 'Malaysia'),
(16, '', '2019-07-16', '2019-07-17', '', 'PAID', 120, 12, '2019-07-15 17:18:54', 'Syafiq Tajudin', 'Roslan', 'syafiqtajudin@gmail.com', '1123743773', 'no 2, taman emas baru, kampung emas', '', 'Temerloh', 'Pahang', '23477', 'Malaysia'),
(17, '', '2019-07-23', '2019-07-24', '', 'pending', 150, 15, '2019-07-16 18:41:25', 'salim', 'mahmud', 'red@gmail.com', '0331204957', 'no 2 jalan bb3/6', 'taman banting', 'SUNGAI BESAR', 'selangor', '42700', 'Malaysia'),
(18, '', '2019-07-17', '2019-07-18', '', 'PAID', 180, 18, '2019-07-17 01:50:52', 'Syafiq', 'Roslan', 'syafiqtajudin@gmail.com', '1123743773', 'no 2, taman emas baru, kampung emas', '', 'Temerloh', 'Pahang', '23477', 'Malaysia'),
(19, '', '2019-07-17', '2019-07-18', '', 'pending', 120, 12, '2019-07-17 02:12:13', 'Syafiq', 'Roslan', 'syafiqtajudin@gmail.com', '1123743773', 'no 2, taman emas baru, kampung emas', '', 'Temerloh', 'Pahang', '23477', 'Malaysia'),
(20, '', '2019-07-26', '2019-07-31', '', 'PENDING PAYMENT', 750, 75, '2019-07-17 03:22:21', 'Syafiq', 'Roslan', 'syafiqtajudin@gmail.com', '1123743773', 'no 2, taman emas baru, kampung emas', '', 'Temerloh', 'Pahang', '23477', 'Malaysia'),
(21, '', '2019-07-19', '2019-07-20', '', 'pending', 120, 12, '2019-07-17 03:36:20', 'Syafiq', 'Roslan', 'syafiqtajudin@gmail.com', '1123743773', 'no 2, taman emas baru, kampung emas', '', 'Temerloh', 'Pahang', '23477', 'Malaysia'),
(22, '', '2019-07-20', '2019-07-21', '', 'pending', 120, 12, '2019-07-17 03:50:54', 'Syafiq', 'Roslan', 'syafiqtajudin@gmail.com', '1123743773', 'no 2, taman emas baru, kampung emas', '', 'Temerloh', 'Pahang', '23477', 'Malaysia');

-- --------------------------------------------------------

--
-- Table structure for table `homestay`
--

CREATE TABLE `homestay` (
  `homestay_id` int(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_room` int(255) NOT NULL,
  `type_homestay` varchar(255) DEFAULT NULL,
  `parking_no` int(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `homestay_name` varchar(50) NOT NULL,
  `descriptions` text,
  `rate` double NOT NULL,
  `imgpath` varchar(100) NOT NULL,
  `total_homestay` int(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homestay`
--

INSERT INTO `homestay` (`homestay_id`, `user_id`, `total_room`, `type_homestay`, `parking_no`, `address`, `homestay_name`, `descriptions`, `rate`, `imgpath`, `total_homestay`, `id`) VALUES
(11, 12, 3, 'Teres', 2, 'No 32,Jalan Sejati 9A, Taman Sejati,Ijok,45700 Bestari Jaya, Selangor', 'Permai Homestay Ijok', 'Permai Homestay Ijok berdekatan 9KM dari Unisel Kampus Bestari Jaya, terdapat 2 stesen minyak berhampiran dan berdekatan dengan pekan ijok', 120, 'img/permai homestay ijok.jpg', 1, 0),
(12, 11, 3, 'Teres 1 tingkat', 2, 'LOT. 108,  JLN DATO MUSKAM,  TIANG LAMPU (TNB JDM 9) ,Belakang MASJID IJOK Bt. 8, IJOK,  45600 Bestari Jaya, Se;angor.', 'IJOK HOMESTAY', '3~15 min. dari Homestay â€¢MASJID â€¢Deretan Kedai Makan â€¢Serbaneka (7eleven, Yuyi, KFC, McDONALD,OneFRESH) 99Speedmart, Saveway, Dobi 24H, bengkel kereta & pelbagai lagi', 180, 'img/homestay ijok 1.jpg', 1, 0),
(13, 11, 4, 'Teres', 2, 'Lorong 8/1F, Sekyen 8, Kota Puteri  Batu Arang , Selangor  48100 Malaysia', 'Kayu Kayu Homestay ', '15 minute to Unisel Bestari Jaya', 150, 'img/kayu kayu homestay.jpg', 1, 0),
(16, 12, 3, 'Teres 2 tingkat', 2, 'no 2, taman emas baru, kampung emas', 'Homestay Cikgu Dijok', 'Berdekatan dengan pekan ijok dan 9km dari unisel bestari jaya', 100, 'img/ckgu dijok.jpg', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `homestaybook`
--

CREATE TABLE `homestaybook` (
  `booking_id` int(111) NOT NULL,
  `homestay_id` int(111) NOT NULL,
  `totalhomestaybook` int(111) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `uploadfile`
--

CREATE TABLE `uploadfile` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `homestay_name` varchar(255) NOT NULL,
  `file` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploadfile`
--

INSERT INTO `uploadfile` (`id`, `email`, `phonenumber`, `homestay_name`, `file`) VALUES
(13, 'Ikhmal@gmail.com', '01459687712', 'Kayu Kayu Homestay ', 'receipt.jpg'),
(14, 'syafiqtajudin@gmail.com', '01123743773', 'Permai Homestay Ijok', 'receipt.jpg'),
(15, 'Faizul@gmail.com', '01238477584', 'Kayu kayu homestay', 'receipt.jpg'),
(16, 'red@gmail.com', '331204957', 'ijok', 'becd.jpg'),
(17, 'syafiqtajudin@gmail.com', '1123743773', 'IJOK HOMESTAY', 'receipt.jpg'),
(18, 'syafiqtajudin@gmail.com', '1123743773', 'Homestay Cikgu D\'ijok', 'resit.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `homestay_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `fullname`, `address`, `email`, `phonenumber`, `password`, `homestay_id`) VALUES
(11, 'Faizul16', 'Muhammad Faizul Kamarozaman', 'No 36, Jalan 3/6 Taman Banting Baru, 41700 Banting, Selangor', 'Fivezul16@gmail.com', '0199893483', 'faizul', 0),
(12, 'Mdsyawal', 'Mohamad Syawal Bin Samsuddin', 'taman ', 'syawalsamsuddin24@gmail.com', '0113113025', 'syawal', 0),
(14, 'Hariz', 'Muhammad Haris Azman', '', 'harisazman@gmail.com', '01123747787', 'hariz', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `homestay`
--
ALTER TABLE `homestay`
  ADD PRIMARY KEY (`homestay_id`);

--
-- Indexes for table `homestaybook`
--
ALTER TABLE `homestaybook`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `uploadfile`
--
ALTER TABLE `uploadfile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `homestay`
--
ALTER TABLE `homestay`
  MODIFY `homestay_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `uploadfile`
--
ALTER TABLE `uploadfile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
